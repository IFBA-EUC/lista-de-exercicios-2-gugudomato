import java.util.Scanner;

public class Questao2 {
    
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        double distante, X1, Y1, Z1, X2, Y2, Z2;

        System.out.println("Digite as primeiras coordenadas: ");
        System.out.println("X1: ");
        X1 = leitor.nextDouble();
        System.out.println("Y1: ");
        Y1 = leitor.nextDouble();
        System.out.println("Z1: ");
        Z1 = leitor.nextDouble();

        System.out.println("Digite as segundas coordenadas: ");
        System.out.println("X2: ");
        X2 = leitor.nextDouble();
        System.out.println("Y2: ");
        Y2 = leitor.nextDouble();
        System.out.println("Z2: ");
        Z2 = leitor.nextDouble();

        distante = Math.sqrt(Math.pow((X2 - X1), 2) + Math.pow((Y2 - Y1), 2) + Math.pow((Z2 - Z1), 2)); 
        System.out.printf("A distancia de acordo com as coordenas é: %f", distante);
        leitor.close();
    }

}
