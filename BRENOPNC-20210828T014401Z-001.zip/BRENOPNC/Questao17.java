import java.util.Scanner;

public class Questao17 {
    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);
        int valor, casa1, casa2, casa3, cas1, cas2, cas3, resto; String center = " ", dezer = " ", unir = " ";

        System.out.print("Digite um número decimal de até 3 digitos: ");
        valor = leitor.nextInt();

        cas1 = valor/100; 
        resto = valor % 100;
        cas2 = resto / 10;
        cas3 = resto % 10;  

        casa1 = cas1 * 100;  
        casa2 = cas2 * 10;   
        casa3 = cas3;      

        String [] centena = {"C", "CC", "CCC", "CD", "C", "DC", "DCC", "DCCC", "CM"}; String [] dezena = {"X", "XX", "XXX", "XL", "L", "LX", "LXX", "LXXX", "XC"}; String [] unidade = {"I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX"}; 

        switch (casa1) {       
            case 100:        
                center = centena[0];
                break;
            case 200:
                center = centena[1];
                break;
            case 300:
                center = centena[2];
                break;
            case 400:
                center = centena[3];
                break;
            case 500:
                center = centena[4];
                break;
            case 600:
                center = centena[5];
                break;
            case 700:
                center = centena[6];
                break;
            case 800:
                center = centena[7];
                break;
            case 900:
                center = centena[8];
                break;
        }  

        switch (casa2) {
            case 10:
                dezer = dezena[0];
                break;
            case 20:
                dezer = dezena[1];
                break;
            case 30:
                dezer = dezena[2];
                break;
            case 40:
                dezer = dezena[3];
                break;
            case 50:
                dezer = dezena[4];
                break;
            case 60:
                dezer = dezena[5];
                break;
            case 70:
                dezer = dezena[6];
                break;
            case 80:
                dezer = dezena[7];
                break;
            case 90:
                dezer = dezena[8];
                break;
        }   

        switch (casa3) {
            case 1:
                unir = unidade[0];
                break;
            case 2:
                unir = unidade[1];
                break;
            case 3:
                unir = unidade[2];
                break;
            case 4:
                unir = unidade[3];
                break;
            case 5:
                unir = unidade[4];
                break;
            case 6:
                unir = unidade[5];
                break;
            case 7:
                unir = unidade[6];
                break;
            case 8:
                unir = unidade[7];
                break;
            case 9:
                unir = unidade[8];
                break;
        }

        if(valor < 10){
            System.out.println(unir);
        }else if(valor < 100 && valor > 9){
            System.out.println( dezer + unir);
        }else{
            System.out.println(center + dezer + unir);
        }

        leitor.close();
    }
}
