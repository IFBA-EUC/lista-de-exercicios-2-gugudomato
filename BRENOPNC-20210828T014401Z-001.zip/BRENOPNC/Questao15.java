public class Questao15 {

    private float media;

//MÉTODOS PERSONALIZADO
    public void media(float nota1, float nota2, float nota3){

        this.media = (nota1 + nota2 + nota3) / 3;
        System.out.println("A media do aluno é: " + media);

    }


    public void status(){
        if(this.media > 6){
            System.out.println("Aprovado");
        }else if(this.media >= 4 && this.media <= 6){
            System.out.println("Verificação Suplementar");
        }else{
            System.out.println("Reprovado");
        }
    }
}  