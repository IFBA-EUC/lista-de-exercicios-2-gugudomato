import java.util.Scanner;

public class Questao4 {
    
    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        String nome; float preco; double valor; int quantidade;

        System.out.printf("Nome: ");
        nome = leitor.nextLine();
        System.out.printf("Preço: ");
        preco = leitor.nextFloat();
        System.out.println("Quantidade: ");
        quantidade = leitor.nextInt();

        if(quantidade <= 10){
            valor = preco * quantidade;
            System.out.println("Nome do produto: " + nome + "\nValor do produto: " + valor);
        }else if(quantidade > 10 && quantidade <= 20){
            valor = (preco * quantidade) * 0.9;
            System.out.println("Nome do produto: " + nome + "\nValor do produto: " + valor);
        }else if(quantidade > 20 && quantidade <= 50){
            valor = (preco * quantidade) * 0.8;
            System.out.println("Nome do produto: " + nome + "\nValor do produto: " + valor);
        }else{
            valor = (preco * quantidade) * 0.75;
            System.out.println("Nome do produto: " + nome+ "\nValor do produto: " + valor);
        }
        leitor.close();

    }

}
