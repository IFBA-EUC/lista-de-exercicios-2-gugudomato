import java.util.Scanner;

public class Questao10 {
    public static void main(String[] args) {
        Scanner leitor = new Scanner(System.in);
        double total = 0, saldo = 0;
        double juros; String r;


        System.out.print("Valor a ser investido: ");
        saldo = leitor.nextFloat();
        System.out.print("Taxa de juros mensal: ");
        juros = leitor.nextDouble();

        do{
            for(int a = 1; a <= 12; a++){
                saldo = saldo + ((saldo * juros) / 100);
                total = total + saldo;
            }
            System.out.println("Saldo do investimento depois de 1 ano: " + total);
            System.out.println("Deseja investir por mais um ano? (S/N) ");
            r = leitor.next();
            saldo = total;

        }while((r.equals("S")) || (r.equals("s")));
        leitor.close();
    }
}