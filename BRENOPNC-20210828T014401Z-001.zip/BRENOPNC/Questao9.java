public class Questao9 {
    /*A SAÍDA DO PROGRAMA será:
    1º saida = 2, 2, 1
    2º saida = 2, 3, 1
    3º saida = 2, 3, 3
    4º saida = 2, 4, 1
    5º saida = 2, 4, 3
    6º saida = 4, 4, 1 */
    public static void main(String[] args) { 
        for (int i = 2; i <= 8; i = i + 2) { 
            for (int j = i; j <= 4; j++) { 
                for (int k = 1; k <= j; k = k + i) { 
                    System.out.println(i + ", " + j + ", " + k); 
                } 
            } 
        } 
    }
}
