import java.util.Scanner;

public class Questao6 {
    
    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        int numero, desd = 10, resc, contador = 0;


        System.out.println("Digite o número para a contagem: ");
        numero = leitor.nextInt();

        do{
            resc = numero / desd;
            contador++;
            desd = desd * 10;
        }while(resc >= 1);

        System.out.printf("O numero tem %d dígito(s)", contador);

        leitor.close();
    }

}
