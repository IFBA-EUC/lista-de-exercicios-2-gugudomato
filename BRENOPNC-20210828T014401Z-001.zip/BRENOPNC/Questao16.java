public class Questao16 {
    
    private int hor, min, seg, guardar;

    public void setTempo(int s){
        this.hor = seg / 3600;
        this.guardar = s % 3600;
        this.min = this.guardar / 60;
        this.guardar = this.guardar % 60;
        this.seg = this.guardar;
    }

    public int getHoras(){
        return this.hor;
    }
    
    public int getMinutos(){
        return this.min;
    }

    public int getSegundos(){
        return this.seg;
    }

    public void status(){
        System.out.println(getHoras()+":"+getMinutos()+":"+getSegundos());
    }


}
