import java.util.Scanner;

public class Questao8 {
    
    public static void main(String[] args) {

        Scanner leitor = new Scanner(System.in);

        int numero, Fib0 = 0, Fib1 = 1, Fibn = 0;

        System.out.printf("Digite um número: ");
        numero = leitor.nextInt();
        
        if(numero < 0){
            System.out.println("ERROR!");
        }else{
            System.out.printf("0 1 ");
            for(int i = 1; i < numero; i++){
                Fibn = Fib1 + Fib0;
                System.out.printf("%d ", Fibn);
                Fib0 = Fib1;
                Fib1 = Fibn;
            }
        }


        leitor.close();
    }

}
